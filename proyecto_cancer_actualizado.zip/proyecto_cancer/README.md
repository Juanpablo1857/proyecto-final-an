# Proyecto Final - Clasificación Binaria

Dataset: Breast Cancer Wisconsin (Diagnostic) de UCI.

## Archivos

- `Proyecto_Final_Clasificacion_Binaria.ipynb`: notebook principal. Descarga el dataset desde UCI, lo convierte a CSV, entrena Regresión Logística y Red Neuronal, calcula matriz de confusión y exactitud.
- `data/breast_cancer_wisconsin_diagnostic.csv`: dataset convertido a CSV.
- `index.html`: página web estática para usar el modelo en GitHub Pages.
- `model/best_model.joblib`: mejor modelo entrenado.
- `model/logistic_web_params.json`: parámetros usados por la página web.
- `model/metrics.json`: resultados del entrenamiento.

## Cómo usar

1. Abrir el notebook en Jupyter o Google Colab.
2. Ejecutar todas las celdas.
3. Abrir `index.html` en el navegador.
4. Para publicar, subir todos los archivos a un repositorio de GitHub y activar GitHub Pages.

## Clases

- `0`: benigno
- `1`: maligno
